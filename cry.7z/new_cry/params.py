CACHE_DATABASE_PARAMS = {
    'host': '127.0.0.1',
    'port': 6379,
    'db': 0,
}

VALUES_DATABASE_PARAMS = "postgresql://postgres:postgres@localhost:5432/postgres"
