BINANCE_WS_URL = 'wss://fstream.binance.com/ws'
BYBIT_WS_URL = 'wss://stream-testnet.bybit.com/v5/market/orderbook'
HUOBI_WS_URL = 'wss://api.huobi.pro/ws'
OKX_WS_URL = 'wss://ws.okx.com:8443/ws/v5/public'
