binance_symbols_mapping = {
    'BTCUSDT': 1,
}

kraken_symbols_mapping = {
    'XBT/USDT': 1,
}

okx_symbols_mapping = {
    'BTC-USDT': 1,
}
